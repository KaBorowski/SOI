#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include "monitor.h"

#define N 9

char buffer[N];
int input = 0;
int output = 0;
int counter = 0;

Semaphore empty = Semaphore(N);
Semaphore reader = Semaphore(1);
Semaphore writer = Semaphore(1);
Semaphore full = Semaphore(0);

void * producer(void *args){
  while(true){
    //produce
    char value = *((char *)args);
    bool canRead = false;
    printf("%c czeka na SK\n", value);
    empty.p();
    //mutex.p();
    writer.p();
    reader.p();
    if(input!=output && input!=(output+1)%N && input!=(output+2)%N){
      canRead = true;
      reader.v();
    }
    printf("%c wchodzi do SK\n", value);
    buffer[input] = value;
    input = (input+1)%N;
    counter++;
    printf("%c opuszcza SK\n", value);
    if(counter>2)
      full.v();
    if (!canRead)
      reader.v();
    //mutex.v();
    writer.v();
    usleep(1000000);
  }
}
void * consumer(void *args){
  while(true){
    char value[3];
    printf("Konsument czeka na SK\n");
    int i;
    full.p();
    //mutex.p();
    reader.p();
    printf("Konsument wchodzi do SK\n");
    counter=counter-3;
    for(i=0; i<3; i++){
      value[i] = buffer[output];
      output = (output+1)%N;
    }
    printf("Konsument opuszcza SK z %c, %c, %c\n", value[0],value[1],value[2]);
    //mutex.v();
    for(i=0; i<3; i++){
      empty.v();
    }
    reader.v();
    usleep(900000);
  }
}
int main(int argc, char const *argv[]) {
  pthread_t pA, pB, pC, pD;
  //pthread pA2, pB2, pC2, pD2;
  char a='a';
  char b='b';

  if(pthread_create(&pA, NULL, producer, &a)||pthread_create(&pB, NULL, producer, &b)||
  pthread_create(&pC, NULL, consumer, &a)||pthread_create(&pD, NULL, consumer, &a)){
    printf("Nie utworzono watku\n");
    return 0;
  }
  // if(pthread_create(&pA2, NULL, consumer, &a)||pthread_create(&pB2, NULL, consumer, &b)||
  // pthread_create(&pC2, NULL, consumer, &a)||pthread_create(&pD2, NULL, consumer, &a)){
  //   printf("Nie utworzono watku\n");
  //   return 0;
  // }
  pthread_join(pA, NULL);
  pthread_join(pB, NULL);
  pthread_join(pC, NULL);
  pthread_join(pD, NULL);
  // pthread_join(pA2, NULL);
  // pthread_join(pB2, NULL);
  // pthread_join(pC2, NULL);
  // pthread_join(pD2, NULL);

  return 0;
}
